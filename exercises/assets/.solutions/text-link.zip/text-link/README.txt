1. Create an empty HTML document
2. Link the provided CSS file
3. Add some placeholder text
4. In it, add a link to the any website
5. Change its look and behaviour:
  - Opens in a new tab
  - Same text colour as the paragraph
  - Underlined
  - Make something happen on hover
