1. Link the provided CSS file
2. Style the website to look like the reference image
  - The font size is 14px (.875rem)
  - The line height is 16.8px (120%)
  - The background colour is black
  - The text colour is white
  - The page has a padding of 14px
  - Each major section is seperated by a 14px gap
  - The language indicators are 14px above the text
  - The texts are seperated by a 14px gap

+ Hints:
- Some properties have been prefilled for you, keep them as they are.
- The body and footer are displayed in a grid, try to see if you can style them.