Recreate the compositions of the reference image using the CSS display property.

+ Hints:
  - This children of the exercise a have a height of 200px.
  - Each child contains value used for its styling.