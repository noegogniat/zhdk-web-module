1. Structure the content of the reference page using semanticaly meaningful HTML tags and attributes
  - You can find the text and image in the assets folder
  - The page doesn't need to be styled

+ Some context:
- The name of the page is "Beispiel"
- The page contains multiple languages: English (EN), German (DE), French (FR), and Dutch (NL)