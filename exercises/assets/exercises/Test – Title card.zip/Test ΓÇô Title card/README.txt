1. Create an empty HTML document
2. Link the provided CSS file
3. At the center of the screen, add a info card:
  - Content: image, title and some text
  - Borders of your choice
  - Rounded corners
  - Make something happen on hover
